<?php

namespace Mpdf\Tag;

class H1 extends BlockTag
{


}
